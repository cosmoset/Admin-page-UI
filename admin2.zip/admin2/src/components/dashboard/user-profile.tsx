"use client";

import { SidebarMenu, SidebarMenuButton, SidebarMenuItem } from "../ui/sidebar";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/handle-error";
import { UserProps } from "@/types";
import ProfileMenu from "../account-menu";

export function UserNav() {
  // Mock user data since we removed authentication
  const mockUser: UserProps = {
    id: "1",
    name: "Demo User",
    email: "demo@example.com",
    image: "https://github.com/shadcn.png",
  };

  const handleLogout = () => {
    toast.success("Logout functionality removed");
  };

  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <SidebarMenuButton
          size="lg"
          className="data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground"
        >
          <ProfileMenu
            user={mockUser}
            logout={handleLogout}
            loading={false}
          />
        </SidebarMenuButton>
      </SidebarMenuItem>
    </SidebarMenu>
  );
}
